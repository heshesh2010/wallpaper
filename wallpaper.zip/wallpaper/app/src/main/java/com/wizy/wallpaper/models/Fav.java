package com.wizy.wallpaper.models;

public class Fav {

    private String img_id;
    private String url;

    public void setImg_id(String img_id) {
        this.img_id = img_id;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getImg_id() {
        return img_id;
    }

    public String getUrl() {
        return url;
    }
}
